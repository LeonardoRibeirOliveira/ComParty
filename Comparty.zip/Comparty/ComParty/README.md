# ComParty
Aplicação desenvolvida na disciplina de Domínios de Software, na qual simula uma balada virtual.

Link do protótipo:
https://www.figma.com/file/A8f3idHgJmQLKF0FE75LFJ/Untitled?type=design&node-id=0%3A1&mode=design&t=rZGn8oNK8ySARbnE-1

